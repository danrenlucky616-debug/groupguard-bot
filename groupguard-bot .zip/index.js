const { default: makeWASocket, DisconnectReason, useSingleFileAuthState } = require('@whiskeysockets/baileys')
const { Boom } = require('@hapi/boom')
const fs = require('fs')

const PREFIX = '.'
const BOT_NAME = 'GroupGuard'
const WARN_LIMIT = 5
const DB_FILE = './warnings.json'

// Load or create DB
let db = fs.existsSync(DB_FILE)? JSON.parse(fs.readFileSync(DB_FILE)) : {}
const saveDB = () => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2))

const getUser = (groupId, userId) => {
    if (!db[groupId]) db[groupId] = {}
    if (!db[groupId][userId]) db[groupId][userId] = { warnings: 0, name: '' }
    return db[groupId][userId]
}

const { state, saveState } = useSingleFileAuthState('./auth_info.json')

async function startBot() {
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    })

    sock.ev.on('creds.update', saveState)

    // WELCOME
    sock.ev.on('group-participants.update', async (update) => {
        if (update.action === 'add') {
            for (const user of update.participants) {
                await sock.sendMessage(update.id, { 
                    text: `👋 Welcome @${user.split('@')[0]} to the group! 🎉\nPlease read and follow the GC rules. 🙏`,
                    mentions: [user]
                })
            }
        }
    })

    // MESSAGE HANDLER
    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0]
        if (!msg.message || msg.key.fromMe) return

        const groupId = msg.key.remoteJid
        const sender = msg.key.participant || msg.key.remoteJid
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || ""
        const isGroup = groupId.endsWith('@g.us')
        if (!isGroup) return

        const metadata = await sock.groupMetadata(groupId)
        const admins = metadata.participants.filter(p => p.admin).map(p => p.id)
        const isAdmin = admins.includes(sender)

        const userData = getUser(groupId, sender)
        userData.name = metadata.participants.find(p => p.id === sender)?.notify || sender.split('@')[0]

        // LINK + STATUS DELETE
        const hasLink = /(https?:\/\/|www\.|\.com|\.ng)/i.test(text)
        const hasStatus = /status/i.test(text)

        if (hasLink) {
            await sock.sendMessage(groupId, { delete: msg.key })
            await sock.sendMessage(groupId, { 
                text: `🗑️ Message deleted\n⚠️ @${sender.split('@')[0]} Links not allowed 🚫`,
                mentions: [sender]
            })
            return addWarning(sock, groupId, sender)
        }

        if (hasStatus) {
            await sock.sendMessage(groupId, { delete: msg.key })
            await sock.sendMessage(groupId, { 
                text: `🗑️ Message deleted\n⚠️ @${sender.split('@')[0]} Status mentions not allowed 🚫`,
                mentions: [sender]
            })
            return addWarning(sock, groupId, sender)
        }

        // SPAM
        if (!userData.msgTimes) userData.msgTimes = []
        userData.msgTimes.push(Date.now())
        userData.msgTimes = userData.msgTimes.filter(t => Date.now() - t < 10000)
        if (userData.msgTimes.length > 5) {
            await sock.sendMessage(groupId, { 
                text: `⚠️ @${sender.split('@')[0]} Stop spamming! 🚫`,
                mentions: [sender]
            })
            addWarning(sock, groupId, sender)
        }

        // COMMANDS
        if (!text.startsWith(PREFIX)) return
        const args = text.slice(PREFIX.length).trim().split(/ +/)
        const command = args.shift().toLowerCase()

        if (['warn','kick','reset','mute','unmute'].includes(command) &&!isAdmin) {
            return sock.sendMessage(groupId, { 
                text: `🚫 @${sender.split('@')[0]} Admins only. 👮`,
                mentions: [sender]
            })
        }

        const target = args[0]?.replace('@', '') + '@s.whatsapp.net'

        if(command === 'menu') return sock.sendMessage(groupId, { text: `🤖 ${BOT_NAME} MENU\n.warn @user\n.warnings @user\n.reset @user\n.kick @user\n.rules\n.mute @user\n.unmute @user` })
        if(command === 'warn') return addWarning(sock, groupId, target, true)
        if(command === 'warnings') {
            const tData = getUser(groupId, target)
            return sock.sendMessage(groupId, { text: `📊 @${target.split('@')[0]}\nWarnings: ${tData.warnings}/${WARN_LIMIT} ⚠️`, mentions: [target] })
        }
        if(command === 'reset') {
            getUser(groupId, target).warnings = 0
            saveDB()
            return sock.sendMessage(groupId, { text: `✅ Warnings reset for @${target.split('@')[0]}`, mentions: [target] })
        }
        if(command === 'kick') return sock.groupParticipantsUpdate(groupId, [target], "remove")
        if(command === 'rules') return sock.sendMessage(groupId, { text: `📋 GC RULES\n🚫 No links\n🚫 No spam\n🚫 No status mentions\n🤝 Respect everyone\n⚠️ 5 warnings = removal` })
    })

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update
        if(connection === 'close') {
            const shouldReconnect = (lastDisconnect.error)?.output?.statusCode!== DisconnectReason.loggedOut
            if(shouldReconnect) startBot()
        }
    })
}

async function addWarning(sock, groupId, userId) {
    const userData = getUser(groupId, userId)
    userData.warnings += 1
    saveDB()
    await sock.sendMessage(groupId, { 
        text: `⚠️ @${userId.split('@')[0]} Warning ${userData.warnings}/${WARN_LIMIT}`,
        mentions: [userId]
    })
    if (userData.warnings >= WARN_LIMIT) {
        await sock.sendMessage(groupId, { 
            text: `🔨 @${userId.split('@')[0]} removed - 5 warnings`,
            mentions: [userId]
        })
        await sock.groupParticipantsUpdate(groupId, [userId], "remove")
        userData.warnings = 0
        saveDB()
    }
}

startBot()